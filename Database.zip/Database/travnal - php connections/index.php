<?php

include 'connection.php';

$conn = Con();

echo "Suucessful Connection!"

ConExit($conn);

?>